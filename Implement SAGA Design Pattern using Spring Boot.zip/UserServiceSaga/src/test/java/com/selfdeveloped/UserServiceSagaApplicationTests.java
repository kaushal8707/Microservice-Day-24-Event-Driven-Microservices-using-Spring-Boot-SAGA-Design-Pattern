package com.selfdeveloped;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserServiceSagaApplicationTests {

	@Test
	void contextLoads() {
	}

}
