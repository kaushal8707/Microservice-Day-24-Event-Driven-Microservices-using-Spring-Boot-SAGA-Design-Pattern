package com.selfdeveloped.OrderService.command.api.saga;
import java.util.UUID;

import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.messaging.responsetypes.ResponseType;
import org.axonframework.messaging.responsetypes.ResponseTypes;
import org.axonframework.modelling.saga.EndSaga;
import org.axonframework.modelling.saga.SagaEventHandler;
import org.axonframework.modelling.saga.StartSaga;
import org.axonframework.queryhandling.QueryGateway;
import org.axonframework.spring.stereotype.Saga;
import org.springframework.beans.factory.annotation.Autowired;

import com.selfdeveloped.CommonService.commands.CancelOrderCommand;
import com.selfdeveloped.CommonService.commands.CancelPaymentCommand;
import com.selfdeveloped.CommonService.commands.CompleteOrderCommand;
import com.selfdeveloped.CommonService.commands.ShipmentOrderCommand;
import com.selfdeveloped.CommonService.commands.ValidatePaymentCommand;
import com.selfdeveloped.CommonService.events.OrderCancelledEvent;
import com.selfdeveloped.CommonService.events.OrderCompletedEvent;
import com.selfdeveloped.CommonService.events.OrderShippedEvent;
import com.selfdeveloped.CommonService.events.PaymentCancelledEvent;
import com.selfdeveloped.CommonService.events.PaymentProcessedEvent;
import com.selfdeveloped.CommonService.model.User;
import com.selfdeveloped.CommonService.queries.GetUserPaymentDetailsQuery;
import com.selfdeveloped.OrderService.command.api.events.OrderCreatedEvent;
import lombok.extern.slf4j.Slf4j;

@Saga
@Slf4j
public class OrderProcessingSaga {

	@Autowired
	private transient CommandGateway commandGateway;
	
	@Autowired
	private transient QueryGateway queryGateway;
	
	public OrderProcessingSaga() {
		
	} 
	@StartSaga
	@SagaEventHandler(associationProperty = "orderId")
	private void handle(OrderCreatedEvent event) {
	log.info("OrderCreatedEvent in Saga for Order Id : {}", event.getOrderId());
	
	
	GetUserPaymentDetailsQuery getUserPaymentDetailsQuery 
			= new GetUserPaymentDetailsQuery(event.getUserId());
	User user=null;
		
	try {
		user=queryGateway.query(getUserPaymentDetailsQuery, ResponseTypes.instanceOf(User.class))
				.join(); 
	}catch(Exception e) {
		log.error(e.getMessage());
		//Start Compensating Transaction
		cancelOrderCommand(event.getOrderId());
		
	}
	
	ValidatePaymentCommand validatePaymentCommand 
			= ValidatePaymentCommand.builder()
			.cardDetails(user.getCardDetails())
			.orderId(event.getOrderId())
			.paymentId(UUID.randomUUID().toString())
			.build();
	commandGateway.sendAndWait(validatePaymentCommand);
	log.info("ValidatePaymentCommand in Saga");

	}
	
	
	private void cancelOrderCommand(String orderId) {
		 
		CancelOrderCommand cancelOrderCommand
					= new CancelOrderCommand(orderId);
		
		commandGateway.send(cancelOrderCommand);
		
	}
	
	
	@SagaEventHandler(associationProperty = "orderId" )
	private void handle(PaymentProcessedEvent event) {
	log.info("PaymentProcessedEvent in Saga for Order Id : {}", event.getOrderId());

	try {
		
//		if(true) {
//			throw new Exception();
//		}
		ShipmentOrderCommand shipmentOrderCommand
					= ShipmentOrderCommand.builder()
					.shipmentId(UUID.randomUUID().toString())
					.orderId(event.getOrderId())
					.build();
			
		commandGateway.sendAndWait(shipmentOrderCommand);
		log.info("ShipOrderCommand in Saga");

	} catch (Exception e) {

		log.error(e.getMessage());
		//Start The Compensating Transaction
		
		//cancelPaymentCommand(event);
	}	
   }
	
	private void cancelPaymentCommand(PaymentProcessedEvent event) {
		
		CancelPaymentCommand cancelPaymentCommand
					= new CancelPaymentCommand(event.getPaymentId(), event.getOrderId());
		commandGateway.send(cancelPaymentCommand);
		
	}
	
	@SagaEventHandler(associationProperty = "orderId" )
	public void handle(OrderShippedEvent event) {
		
		log.info("OrderShippedEvent in Saga for Order Id : {}", event.getOrderId());

		CompleteOrderCommand completeOrderCommand
					= CompleteOrderCommand.builder()
					.orderId(event.getOrderId())
					.orderStatus("APPROVED")
					.build();
		
		commandGateway.sendAndWait(completeOrderCommand);	
	}
	
	@SagaEventHandler(associationProperty = "orderId")
	@EndSaga
	public void handle(OrderCompletedEvent event) {
		
		log.info("OrderCompletedEvent in Saga for Order Id : {}", 
				  event.getOrderId());	
	}
	
	@SagaEventHandler(associationProperty = "orderId")
	@EndSaga
	public void handle(OrderCancelledEvent event) {
		
		log.info("OrderCancelledEvent in Saga for Order Id : {}", 
				  event.getOrderId());	
		
	}
	
	@SagaEventHandler(associationProperty = "orderId")
	public void handle(PaymentCancelledEvent event) {
		
		log.info("PaymentCancelledEvent in Saga for Order Id : {}", 
				  event.getOrderId());
		
		cancelOrderCommand(event.getOrderId());
	}
	
	
	
	
}

	





