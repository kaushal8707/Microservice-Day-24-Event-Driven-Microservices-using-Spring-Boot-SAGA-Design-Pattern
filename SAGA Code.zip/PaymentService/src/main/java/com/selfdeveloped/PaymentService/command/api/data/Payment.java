package com.selfdeveloped.PaymentService.command.api.data;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Builder;
import lombok.Data;

@Data
@Entity
@Builder
public class Payment {

	@Id
	private String paymentId;
	private String orderId;
	private Date timeStamp;
	private String paymentStatus;
}




