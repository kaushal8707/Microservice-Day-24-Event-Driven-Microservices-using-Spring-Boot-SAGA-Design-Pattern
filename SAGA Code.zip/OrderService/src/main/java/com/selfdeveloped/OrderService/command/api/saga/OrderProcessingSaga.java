package com.selfdeveloped.OrderService.command.api.saga;
import java.util.UUID;

import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.messaging.responsetypes.ResponseType;
import org.axonframework.messaging.responsetypes.ResponseTypes;
import org.axonframework.modelling.saga.SagaEventHandler;
import org.axonframework.modelling.saga.StartSaga;
import org.axonframework.queryhandling.QueryGateway;
import org.axonframework.spring.stereotype.Saga;
import org.springframework.beans.factory.annotation.Autowired;

import com.selfdeveloped.CommonService.commands.CompleteOrderCommand;
import com.selfdeveloped.CommonService.commands.ShipOrderCommand;
import com.selfdeveloped.CommonService.commands.ValidatePaymentCommand;
import com.selfdeveloped.CommonService.events.OrderShippedEvent;
import com.selfdeveloped.CommonService.events.PaymentProcessedEvent;
import com.selfdeveloped.CommonService.model.User;
import com.selfdeveloped.CommonService.queries.GetUserPaymentDetailsQuery;
import com.selfdeveloped.OrderService.command.api.events.OrderCreatedEvent;
import lombok.extern.slf4j.Slf4j;

@Saga
@Slf4j
public class OrderProcessingSaga {

	@Autowired
	private CommandGateway commandGateway;
	@Autowired
	private QueryGateway queryGateway;
	
	
	@StartSaga
	@SagaEventHandler(associationProperty = "orderId")
	private void handle(OrderCreatedEvent event) {
	log.info("OrderCreatedEvent in Saga for Order Id : {}", event.getOrderId());
	
	
	GetUserPaymentDetailsQuery getUserPaymentDetailsQuery 
			= new GetUserPaymentDetailsQuery(event.getUserId());
	User user=null;
		
	try {
		user=queryGateway.query(getUserPaymentDetailsQuery, ResponseTypes.instanceOf(User.class))
				.join(); 
	}catch(Exception e) {
		log.error(e.getMessage());
		//Start Compensating Transaction
	}
	
	ValidatePaymentCommand validatePaymentCommand
			= ValidatePaymentCommand.builder()
			.cardDetails(user.getCardDetails())
			.orderId(event.getOrderId())
			.paymentId(UUID.randomUUID().toString())
			.build();
	commandGateway.sendAndWait(validatePaymentCommand);
	}
	
	
	@SagaEventHandler(associationProperty = "orderId" )
	private void handle(PaymentProcessedEvent event) {
	log.info("PaymentProcessedEvent in Saga for Order Id : {}", event.getOrderId());

	try {
		ShipOrderCommand shipOrderCommand
					= ShipOrderCommand.builder()
					.shipmentId(UUID.randomUUID().toString())
					.orderId(event.getOrderId())
					.build();
			
		commandGateway.send(shipOrderCommand);
	} catch (Exception e) {

		log.error(e.getMessage());
		//Start The Compensating Transaction	
	}	
   }
	
	@SagaEventHandler(associationProperty = "orderId" )
	public void handle(OrderShippedEvent event) {
		
		log.info("OrderShippedEvent in Saga for Order Id : {}", event.getOrderId());

		CompleteOrderCommand completeOrderCommand
					= CompleteOrderCommand.builder()
					.orderId(event.getOrderId())
					.orderStatus("APPROVED")
					.build();
		
		commandGateway.send(completeOrderCommand);	
	}
	
}

	





