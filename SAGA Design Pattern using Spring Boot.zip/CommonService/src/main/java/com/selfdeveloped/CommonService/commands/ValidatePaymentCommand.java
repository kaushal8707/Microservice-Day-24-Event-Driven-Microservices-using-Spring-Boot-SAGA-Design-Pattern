package com.selfdeveloped.CommonService.commands;
import org.axonframework.modelling.command.TargetAggregateIdentifier;
import com.selfdeveloped.CommonService.model.CardDetails;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Getter
@Builder
public class ValidatePaymentCommand {
	@TargetAggregateIdentifier
	private String paymentId;
	private String orderId;
	private CardDetails cardDetails;
}


