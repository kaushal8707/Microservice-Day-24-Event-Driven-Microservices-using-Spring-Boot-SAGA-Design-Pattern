package com.selfdeveloped.CommonService.commands;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class ShipmentOrderCommand {
	@TargetAggregateIdentifier
	private String shipmentId;
	private String orderId;
}
